#define rand	pan_rand
#if defined(HAS_CODE) && defined(VERBOSE)
	printf("Pr: %d Tr: %d\n", II, t->forw);
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* PROC :never: */
	case 3: /* STATE 1 - line 263 "pan_in" - [(flaw)] (0:0:0 - 1) */
		
#if defined(VERI) && !defined(NP)
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim reached state %d (line %d)\n",
					depth, frm_st0[t->forw], src_claim[1]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
		reached[4][1] = 1;
		if (!(((int)now.flaw)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: /* STATE 8 - line 268 "pan_in" - [-end-] (0:0:0 - 1) */
		
#if defined(VERI) && !defined(NP)
		{	static int reported8 = 0;
			if (verbose && !reported8)
			{	printf("depth %d: Claim reached state %d (line %d)\n",
					depth, frm_st0[t->forw], src_claim[8]);
				reported8 = 1;
				fflush(stdout);
		}	}
#endif
		reached[4][8] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC procI */
	case 5: /* STATE 1 - line 159 "pan_in" - [known_nonce[1] = 1] (0:239:2 - 1) */
		IfNotBlocked
		reached[3][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.known_nonce[1]);
		now.known_nonce[1] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[1]", ((int)now.known_nonce[1]));
#endif
		;
		/* merge: known_key[1] = 1(239, 2, 239) */
		reached[3][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.known_key[1]);
		now.known_key[1] = 1;
#ifdef VAR_RANGES
		logval("known_key[1]", ((int)now.known_key[1]));
#endif
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 6: /* STATE 4 - line 165 "pan_in" - [proc_chan[1].C?msg,0,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[3][4] = 1;
		if (boq != now.proc_chan[1].C) continue;
		if (q_len(now.proc_chan[1].C) == 0) continue;

		XX=1;
		if (0 != qrecv(now.proc_chan[1].C, 0, 1, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)this)->data.info2);
		;
		((P3 *)this)->msg = qrecv(now.proc_chan[1].C, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("procI:msg", ((P3 *)this)->msg);
#endif
		;
		((P3 *)this)->data.key = qrecv(now.proc_chan[1].C, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		((P3 *)this)->data.info1 = qrecv(now.proc_chan[1].C, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		((P3 *)this)->data.info2 = qrecv(now.proc_chan[1].C, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.proc_chan[1].C);
		sprintf(simtmp, "%d", ((P3 *)this)->msg); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.proc_chan[1].C))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 7: /* STATE 5 - line 166 "pan_in" - [proc_chan[2].C?msg,0,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[3][5] = 1;
		if (boq != now.proc_chan[2].C) continue;
		if (q_len(now.proc_chan[2].C) == 0) continue;

		XX=1;
		if (0 != qrecv(now.proc_chan[2].C, 0, 1, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)this)->data.info2);
		;
		((P3 *)this)->msg = qrecv(now.proc_chan[2].C, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("procI:msg", ((P3 *)this)->msg);
#endif
		;
		((P3 *)this)->data.key = qrecv(now.proc_chan[2].C, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		((P3 *)this)->data.info1 = qrecv(now.proc_chan[2].C, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		((P3 *)this)->data.info2 = qrecv(now.proc_chan[2].C, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.proc_chan[2].C);
		sprintf(simtmp, "%d", ((P3 *)this)->msg); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.proc_chan[2].C))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 8: /* STATE 6 - line 167 "pan_in" - [proc_chan[3].C?msg,0,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[3][6] = 1;
		if (boq != now.proc_chan[3].C) continue;
		if (q_len(now.proc_chan[3].C) == 0) continue;

		XX=1;
		if (0 != qrecv(now.proc_chan[3].C, 0, 1, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)this)->data.info2);
		;
		((P3 *)this)->msg = qrecv(now.proc_chan[3].C, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("procI:msg", ((P3 *)this)->msg);
#endif
		;
		((P3 *)this)->data.key = qrecv(now.proc_chan[3].C, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		((P3 *)this)->data.info1 = qrecv(now.proc_chan[3].C, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		((P3 *)this)->data.info2 = qrecv(now.proc_chan[3].C, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.proc_chan[3].C);
		sprintf(simtmp, "%d", ((P3 *)this)->msg); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.proc_chan[3].C))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 9: /* STATE 7 - line 168 "pan_in" - [proc_chan[4].C?msg,0,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[3][7] = 1;
		if (boq != now.proc_chan[4].C) continue;
		if (q_len(now.proc_chan[4].C) == 0) continue;

		XX=1;
		if (0 != qrecv(now.proc_chan[4].C, 0, 1, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)this)->data.info2);
		;
		((P3 *)this)->msg = qrecv(now.proc_chan[4].C, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("procI:msg", ((P3 *)this)->msg);
#endif
		;
		((P3 *)this)->data.key = qrecv(now.proc_chan[4].C, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		((P3 *)this)->data.info1 = qrecv(now.proc_chan[4].C, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		((P3 *)this)->data.info2 = qrecv(now.proc_chan[4].C, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.proc_chan[4].C);
		sprintf(simtmp, "%d", ((P3 *)this)->msg); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.proc_chan[4].C))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 10: /* STATE 8 - line 169 "pan_in" - [proc_chan[5].C?msg,0,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[3][8] = 1;
		if (boq != now.proc_chan[5].C) continue;
		if (q_len(now.proc_chan[5].C) == 0) continue;

		XX=1;
		if (0 != qrecv(now.proc_chan[5].C, 0, 1, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)this)->data.info2);
		;
		((P3 *)this)->msg = qrecv(now.proc_chan[5].C, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("procI:msg", ((P3 *)this)->msg);
#endif
		;
		((P3 *)this)->data.key = qrecv(now.proc_chan[5].C, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		((P3 *)this)->data.info1 = qrecv(now.proc_chan[5].C, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		((P3 *)this)->data.info2 = qrecv(now.proc_chan[5].C, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.proc_chan[5].C);
		sprintf(simtmp, "%d", ((P3 *)this)->msg); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.proc_chan[5].C))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 11: /* STATE 9 - line 170 "pan_in" - [proc_chan[6].C?msg,0,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[3][9] = 1;
		if (boq != now.proc_chan[6].C) continue;
		if (q_len(now.proc_chan[6].C) == 0) continue;

		XX=1;
		if (0 != qrecv(now.proc_chan[6].C, 0, 1, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)this)->data.info2);
		;
		((P3 *)this)->msg = qrecv(now.proc_chan[6].C, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("procI:msg", ((P3 *)this)->msg);
#endif
		;
		((P3 *)this)->data.key = qrecv(now.proc_chan[6].C, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		((P3 *)this)->data.info1 = qrecv(now.proc_chan[6].C, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		((P3 *)this)->data.info2 = qrecv(now.proc_chan[6].C, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.proc_chan[6].C);
		sprintf(simtmp, "%d", ((P3 *)this)->msg); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.proc_chan[6].C))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 12: /* STATE 10 - line 171 "pan_in" - [proc_chan[7].C?msg,0,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[3][10] = 1;
		if (boq != now.proc_chan[7].C) continue;
		if (q_len(now.proc_chan[7].C) == 0) continue;

		XX=1;
		if (0 != qrecv(now.proc_chan[7].C, 0, 1, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)this)->data.info2);
		;
		((P3 *)this)->msg = qrecv(now.proc_chan[7].C, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("procI:msg", ((P3 *)this)->msg);
#endif
		;
		((P3 *)this)->data.key = qrecv(now.proc_chan[7].C, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		((P3 *)this)->data.info1 = qrecv(now.proc_chan[7].C, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		((P3 *)this)->data.info2 = qrecv(now.proc_chan[7].C, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", now.proc_chan[7].C);
		sprintf(simtmp, "%d", ((P3 *)this)->msg); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(now.proc_chan[7].C))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 13: /* STATE 13 - line 175 "pan_in" - [((s_ptr<10))] (104:0:5 - 1) */
		IfNotBlocked
		reached[3][13] = 1;
		if (!((((int)now.s_ptr)<10)))
			continue;
		/* merge: stored_mesg[s_ptr].msg_type = msg(104, 14, 104) */
		reached[3][14] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = now.stored_mesg[ Index(((int)now.s_ptr), 10) ].msg_type;
		now.stored_mesg[ Index(now.s_ptr, 10) ].msg_type = ((P3 *)this)->msg;
#ifdef VAR_RANGES
		logval("stored_mesg[s_ptr].msg_type", now.stored_mesg[ Index(((int)now.s_ptr), 10) ].msg_type);
#endif
		;
		/* merge: stored_mesg[s_ptr].data.key = data.key(104, 15, 104) */
		reached[3][15] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.stored_mesg[ Index(((int)now.s_ptr), 10) ].data.key);
		now.stored_mesg[ Index(now.s_ptr, 10) ].data.key = ((int)((P3 *)this)->data.key);
#ifdef VAR_RANGES
		logval("stored_mesg[s_ptr].data.key", ((int)now.stored_mesg[ Index(((int)now.s_ptr), 10) ].data.key));
#endif
		;
		/* merge: stored_mesg[s_ptr].data.info1 = data.info1(104, 16, 104) */
		reached[3][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.stored_mesg[ Index(((int)now.s_ptr), 10) ].data.info1);
		now.stored_mesg[ Index(now.s_ptr, 10) ].data.info1 = ((int)((P3 *)this)->data.info1);
#ifdef VAR_RANGES
		logval("stored_mesg[s_ptr].data.info1", ((int)now.stored_mesg[ Index(((int)now.s_ptr), 10) ].data.info1));
#endif
		;
		/* merge: stored_mesg[s_ptr].data.info2 = data.info2(104, 17, 104) */
		reached[3][17] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.stored_mesg[ Index(((int)now.s_ptr), 10) ].data.info2);
		now.stored_mesg[ Index(now.s_ptr, 10) ].data.info2 = ((int)((P3 *)this)->data.info2);
#ifdef VAR_RANGES
		logval("stored_mesg[s_ptr].data.info2", ((int)now.stored_mesg[ Index(((int)now.s_ptr), 10) ].data.info2));
#endif
		;
		/* merge: s_ptr = (s_ptr+1)(104, 18, 104) */
		reached[3][18] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.s_ptr);
		now.s_ptr = (((int)now.s_ptr)+1);
#ifdef VAR_RANGES
		logval("s_ptr", ((int)now.s_ptr));
#endif
		;
		/* merge: .(goto)(0, 22, 104) */
		reached[3][22] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 14: /* STATE 23 - line 185 "pan_in" - [((msg==msg1))] (43:0:4 - 1) */
		IfNotBlocked
		reached[3][23] = 1;
		if (!((((P3 *)this)->msg==3)))
			continue;
		/* dead 1: msg */  (trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)this)->msg = 0;
		/* merge: j = data.info1(43, 24, 43) */
		reached[3][24] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->j);
		((P3 *)this)->j = ((int)((P3 *)this)->data.info1);
#ifdef VAR_RANGES
		logval("procI:j", ((int)((P3 *)this)->j));
#endif
		;
		/* dead 2: j */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)this)->j = 0;
		/* merge: k = data.info2(43, 25, 43) */
		reached[3][25] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->k);
		((P3 *)this)->k = ((int)((P3 *)this)->data.info2);
#ifdef VAR_RANGES
		logval("procI:k", ((int)((P3 *)this)->k));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 15: /* STATE 26 - line 188 "pan_in" - [(known_key[data.key])] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][26] = 1;
		if (!(((int)now.known_key[ Index(((int)((P3 *)this)->data.key), 8) ])))
			continue;
		_m = 3; goto P999; /* 0 */
	case 16: /* STATE 27 - line 190 "pan_in" - [(!(known_nonce[k]))] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][27] = 1;
		if (!( !(((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 17: /* STATE 28 - line 56 "pan_in" - [((nonce_introduced[k]==1))] (239:0:2 - 1) */
		IfNotBlocked
		reached[3][28] = 1;
		if (!((((int)now.nonce_introduced[ Index(((int)((P3 *)this)->k), 8) ])==1)))
			continue;
		/* merge: flaw = 1(239, 29, 239) */
		reached[3][29] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.flaw);
		now.flaw = 1;
#ifdef VAR_RANGES
		logval("flaw", ((int)now.flaw));
#endif
		;
		/* merge: .(goto)(239, 33, 239) */
		reached[3][33] = 1;
		;
		/* merge: .(goto)(239, 38, 239) */
		reached[3][38] = 1;
		;
		/* merge: known_nonce[k] = 1(239, 39, 239) */
		reached[3][39] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:k]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 44, 239) */
		reached[3][44] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 18: /* STATE 31 - line 58 "pan_in" - [(1)] (239:0:1 - 1) */
		IfNotBlocked
		reached[3][31] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(239, 33, 239) */
		reached[3][33] = 1;
		;
		/* merge: .(goto)(239, 38, 239) */
		reached[3][38] = 1;
		;
		/* merge: known_nonce[k] = 1(239, 39, 239) */
		reached[3][39] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:k]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 44, 239) */
		reached[3][44] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 19: /* STATE 36 - line 191 "pan_in" - [(1)] (239:0:1 - 1) */
		IfNotBlocked
		reached[3][36] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(239, 38, 239) */
		reached[3][38] = 1;
		;
		/* merge: known_nonce[k] = 1(239, 39, 239) */
		reached[3][39] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:k]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 44, 239) */
		reached[3][44] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 20: /* STATE 39 - line 193 "pan_in" - [known_nonce[k] = 1] (0:239:1 - 5) */
		IfNotBlocked
		reached[3][39] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:k]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 44, 239) */
		reached[3][44] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 21: /* STATE 44 - line 197 "pan_in" - [.(goto)] (0:239:0 - 2) */
		IfNotBlocked
		reached[3][44] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 22: /* STATE 41 - line 194 "pan_in" - [(1)] (239:0:1 - 1) */
		IfNotBlocked
		reached[3][41] = 1;
		if (!(1))
			continue;
		/* merge: nonce_introduced[k] = 1(239, 42, 239) */
		reached[3][42] = 1;
		(trpt+1)->bup.oval = ((int)now.nonce_introduced[ Index(((int)((P3 *)this)->k), 8) ]);
		now.nonce_introduced[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("nonce_introduced[procI:k]", ((int)now.nonce_introduced[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 44, 239) */
		reached[3][44] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 23: /* STATE 105 - line 233 "pan_in" - [.(goto)] (0:239:0 - 4) */
		IfNotBlocked
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 24: /* STATE 45 - line 197 "pan_in" - [((msg==msg2))] (79:0:3 - 1) */
		IfNotBlocked
		reached[3][45] = 1;
		if (!((((P3 *)this)->msg==2)))
			continue;
		/* dead 1: msg */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)this)->msg = 0;
		/* merge: j = data.info1(79, 46, 79) */
		reached[3][46] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->j);
		((P3 *)this)->j = ((int)((P3 *)this)->data.info1);
#ifdef VAR_RANGES
		logval("procI:j", ((int)((P3 *)this)->j));
#endif
		;
		/* merge: k = data.info2(79, 47, 79) */
		reached[3][47] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->k);
		((P3 *)this)->k = ((int)((P3 *)this)->data.info2);
#ifdef VAR_RANGES
		logval("procI:k", ((int)((P3 *)this)->k));
#endif
		;
		_m = 3; goto P999; /* 2 */
/* STATE 48 - line 200 "pan_in" - [(known_key[data.key])] (0:0 - 1) same as 15 (0:0 - 1) */
	case 25: /* STATE 49 - line 202 "pan_in" - [(!(known_nonce[j]))] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][49] = 1;
		if (!( !(((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 26: /* STATE 50 - line 56 "pan_in" - [((nonce_introduced[j]==1))] (72:0:2 - 1) */
		IfNotBlocked
		reached[3][50] = 1;
		if (!((((int)now.nonce_introduced[ Index(((int)((P3 *)this)->j), 8) ])==1)))
			continue;
		/* merge: flaw = 1(72, 51, 72) */
		reached[3][51] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.flaw);
		now.flaw = 1;
#ifdef VAR_RANGES
		logval("flaw", ((int)now.flaw));
#endif
		;
		/* merge: .(goto)(72, 55, 72) */
		reached[3][55] = 1;
		;
		/* merge: .(goto)(72, 60, 72) */
		reached[3][60] = 1;
		;
		/* merge: known_nonce[j] = 1(72, 61, 72) */
		reached[3][61] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:j]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 27: /* STATE 53 - line 58 "pan_in" - [(1)] (72:0:1 - 1) */
		IfNotBlocked
		reached[3][53] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(72, 55, 72) */
		reached[3][55] = 1;
		;
		/* merge: .(goto)(72, 60, 72) */
		reached[3][60] = 1;
		;
		/* merge: known_nonce[j] = 1(72, 61, 72) */
		reached[3][61] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:j]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 28: /* STATE 58 - line 204 "pan_in" - [(1)] (72:0:1 - 1) */
		IfNotBlocked
		reached[3][58] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(72, 60, 72) */
		reached[3][60] = 1;
		;
		/* merge: known_nonce[j] = 1(72, 61, 72) */
		reached[3][61] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:j]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 29: /* STATE 61 - line 206 "pan_in" - [known_nonce[j] = 1] (0:72:1 - 5) */
		IfNotBlocked
		reached[3][61] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:j]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		_m = 3; goto P999; /* 0 */
/* STATE 62 - line 208 "pan_in" - [(!(known_nonce[k]))] (0:0 - 1) same as 16 (0:0 - 1) */
	case 30: /* STATE 63 - line 56 "pan_in" - [((nonce_introduced[k]==1))] (239:0:2 - 1) */
		IfNotBlocked
		reached[3][63] = 1;
		if (!((((int)now.nonce_introduced[ Index(((int)((P3 *)this)->k), 8) ])==1)))
			continue;
		/* merge: flaw = 1(239, 64, 239) */
		reached[3][64] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.flaw);
		now.flaw = 1;
#ifdef VAR_RANGES
		logval("flaw", ((int)now.flaw));
#endif
		;
		/* merge: .(goto)(239, 68, 239) */
		reached[3][68] = 1;
		;
		/* merge: .(goto)(239, 73, 239) */
		reached[3][73] = 1;
		;
		/* merge: known_nonce[k] = 1(239, 74, 239) */
		reached[3][74] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:k]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 80, 239) */
		reached[3][80] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 31: /* STATE 66 - line 58 "pan_in" - [(1)] (239:0:1 - 1) */
		IfNotBlocked
		reached[3][66] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(239, 68, 239) */
		reached[3][68] = 1;
		;
		/* merge: .(goto)(239, 73, 239) */
		reached[3][73] = 1;
		;
		/* merge: known_nonce[k] = 1(239, 74, 239) */
		reached[3][74] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:k]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 80, 239) */
		reached[3][80] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 32: /* STATE 71 - line 210 "pan_in" - [(1)] (239:0:1 - 1) */
		IfNotBlocked
		reached[3][71] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(239, 73, 239) */
		reached[3][73] = 1;
		;
		/* merge: known_nonce[k] = 1(239, 74, 239) */
		reached[3][74] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:k]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 80, 239) */
		reached[3][80] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 33: /* STATE 74 - line 213 "pan_in" - [known_nonce[k] = 1] (0:239:1 - 5) */
		IfNotBlocked
		reached[3][74] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:k]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 80, 239) */
		reached[3][80] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 34: /* STATE 80 - line 218 "pan_in" - [.(goto)] (0:239:0 - 2) */
		IfNotBlocked
		reached[3][80] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 35: /* STATE 76 - line 214 "pan_in" - [(1)] (239:0:2 - 1) */
		IfNotBlocked
		reached[3][76] = 1;
		if (!(1))
			continue;
		/* merge: nonce_introduced[j] = 1(239, 77, 239) */
		reached[3][77] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.nonce_introduced[ Index(((int)((P3 *)this)->j), 8) ]);
		now.nonce_introduced[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("nonce_introduced[procI:j]", ((int)now.nonce_introduced[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		/* merge: nonce_introduced[k] = 1(239, 78, 239) */
		reached[3][78] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.nonce_introduced[ Index(((int)((P3 *)this)->k), 8) ]);
		now.nonce_introduced[ Index(((P3 *)this)->k, 8) ] = 1;
#ifdef VAR_RANGES
		logval("nonce_introduced[procI:k]", ((int)now.nonce_introduced[ Index(((int)((P3 *)this)->k), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 80, 239) */
		reached[3][80] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 36: /* STATE 81 - line 218 "pan_in" - [((msg==msg3))] (100:0:2 - 1) */
		IfNotBlocked
		reached[3][81] = 1;
		if (!((((P3 *)this)->msg==1)))
			continue;
		/* dead 1: msg */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)this)->msg = 0;
		/* merge: j = data.info1(0, 82, 100) */
		reached[3][82] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->j);
		((P3 *)this)->j = ((int)((P3 *)this)->data.info1);
#ifdef VAR_RANGES
		logval("procI:j", ((int)((P3 *)this)->j));
#endif
		;
		_m = 3; goto P999; /* 1 */
/* STATE 83 - line 221 "pan_in" - [(known_key[data.key])] (0:0 - 1) same as 15 (0:0 - 1) */
/* STATE 84 - line 223 "pan_in" - [(!(known_nonce[j]))] (0:0 - 1) same as 25 (0:0 - 1) */
	case 37: /* STATE 85 - line 56 "pan_in" - [((nonce_introduced[j]==1))] (239:0:2 - 1) */
		IfNotBlocked
		reached[3][85] = 1;
		if (!((((int)now.nonce_introduced[ Index(((int)((P3 *)this)->j), 8) ])==1)))
			continue;
		/* merge: flaw = 1(239, 86, 239) */
		reached[3][86] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.flaw);
		now.flaw = 1;
#ifdef VAR_RANGES
		logval("flaw", ((int)now.flaw));
#endif
		;
		/* merge: .(goto)(239, 90, 239) */
		reached[3][90] = 1;
		;
		/* merge: .(goto)(239, 95, 239) */
		reached[3][95] = 1;
		;
		/* merge: known_nonce[j] = 1(239, 96, 239) */
		reached[3][96] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:j]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 101, 239) */
		reached[3][101] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 38: /* STATE 88 - line 58 "pan_in" - [(1)] (239:0:1 - 1) */
		IfNotBlocked
		reached[3][88] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(239, 90, 239) */
		reached[3][90] = 1;
		;
		/* merge: .(goto)(239, 95, 239) */
		reached[3][95] = 1;
		;
		/* merge: known_nonce[j] = 1(239, 96, 239) */
		reached[3][96] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:j]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 101, 239) */
		reached[3][101] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 39: /* STATE 93 - line 225 "pan_in" - [(1)] (239:0:1 - 1) */
		IfNotBlocked
		reached[3][93] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(239, 95, 239) */
		reached[3][95] = 1;
		;
		/* merge: known_nonce[j] = 1(239, 96, 239) */
		reached[3][96] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:j]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 101, 239) */
		reached[3][101] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 40: /* STATE 96 - line 227 "pan_in" - [known_nonce[j] = 1] (0:239:1 - 5) */
		IfNotBlocked
		reached[3][96] = 1;
		(trpt+1)->bup.oval = ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]);
		now.known_nonce[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("known_nonce[procI:j]", ((int)now.known_nonce[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 101, 239) */
		reached[3][101] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 41: /* STATE 101 - line 231 "pan_in" - [.(goto)] (0:239:0 - 2) */
		IfNotBlocked
		reached[3][101] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 42: /* STATE 98 - line 228 "pan_in" - [(1)] (239:0:1 - 1) */
		IfNotBlocked
		reached[3][98] = 1;
		if (!(1))
			continue;
		/* merge: nonce_introduced[j] = 1(239, 99, 239) */
		reached[3][99] = 1;
		(trpt+1)->bup.oval = ((int)now.nonce_introduced[ Index(((int)((P3 *)this)->j), 8) ]);
		now.nonce_introduced[ Index(((P3 *)this)->j, 8) ] = 1;
#ifdef VAR_RANGES
		logval("nonce_introduced[procI:j]", ((int)now.nonce_introduced[ Index(((int)((P3 *)this)->j), 8) ]));
#endif
		;
		/* merge: .(goto)(239, 101, 239) */
		reached[3][101] = 1;
		;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 43: /* STATE 103 - line 231 "pan_in" - [(1)] (239:0:0 - 1) */
		IfNotBlocked
		reached[3][103] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(239, 105, 239) */
		reached[3][105] = 1;
		;
		/* merge: .(goto)(0, 240, 239) */
		reached[3][240] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 44: /* STATE 107 - line 62 "pan_in" - [i = 0] (0:0:1 - 1) */
		IfNotBlocked
		reached[3][107] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->i);
		((P3 *)this)->i = 0;
#ifdef VAR_RANGES
		logval("procI:i", ((int)((P3 *)this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 45: /* STATE 108 - line 64 "pan_in" - [((i>s_ptr))] (137:0:1 - 1) */
		IfNotBlocked
		reached[3][108] = 1;
		if (!((((int)((P3 *)this)->i)>((int)now.s_ptr))))
			continue;
		/* dead 1: i */  (trpt+1)->bup.oval = ((P3 *)this)->i;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)this)->i = 0;
		/* merge: goto :b6(0, 109, 137) */
		reached[3][109] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 46: /* STATE 111 - line 67 "pan_in" - [(1)] (128:0:4 - 1) */
		IfNotBlocked
		reached[3][111] = 1;
		if (!(1))
			continue;
		/* merge: msg = stored_mesg[i].msg_type(128, 112, 128) */
		reached[3][112] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->msg;
		((P3 *)this)->msg = now.stored_mesg[ Index(((int)((P3 *)this)->i), 10) ].msg_type;
#ifdef VAR_RANGES
		logval("procI:msg", ((P3 *)this)->msg);
#endif
		;
		/* merge: data.key = stored_mesg[i].data.key(128, 113, 128) */
		reached[3][113] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		((P3 *)this)->data.key = ((int)now.stored_mesg[ Index(((int)((P3 *)this)->i), 10) ].data.key);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		/* merge: data.info1 = stored_mesg[i].data.info1(128, 114, 128) */
		reached[3][114] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)now.stored_mesg[ Index(((int)((P3 *)this)->i), 10) ].data.info1);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		/* merge: data.info2 = stored_mesg[i].data.info2(128, 115, 128) */
		reached[3][115] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)this)->data.info2);
		((P3 *)this)->data.info2 = ((int)now.stored_mesg[ Index(((int)((P3 *)this)->i), 10) ].data.info2);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 47: /* STATE 116 - line 43 "pan_in" - [i = 1] (0:0:1 - 1) */
		IfNotBlocked
		reached[3][116] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->i);
		((P3 *)this)->i = 1;
#ifdef VAR_RANGES
		logval("procI:i", ((int)((P3 *)this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 48: /* STATE 118 - line 46 "pan_in" - [i = (i+1)] (0:0:1 - 1) */
		IfNotBlocked
		reached[3][118] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->i);
		((P3 *)this)->i = (((int)((P3 *)this)->i)+1);
#ifdef VAR_RANGES
		logval("procI:i", ((int)((P3 *)this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 49: /* STATE 119 - line 48 "pan_in" - [((i==(8-1)))] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][119] = 1;
		if (!((((int)((P3 *)this)->i)==(8-1))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 50: /* STATE 129 - line 74 "pan_in" - [proc_chan[i].C!msg,1,data.key,data.info1,data.info2] (0:0:0 - 4) */
		IfNotBlocked
		reached[3][129] = 1;
		if (q_len(now.proc_chan[ Index(((int)((P3 *)this)->i), 8) ].C))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", now.proc_chan[ Index(((int)((P3 *)this)->i), 8) ].C);
		sprintf(simtmp, "%d", ((P3 *)this)->msg); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.proc_chan[ Index(((int)((P3 *)this)->i), 8) ].C, 0, ((P3 *)this)->msg, 1, ((int)((P3 *)this)->data.key), ((int)((P3 *)this)->data.info1), ((int)((P3 *)this)->data.info2));
		{ boq = now.proc_chan[ Index(((int)((P3 *)this)->i), 8) ].C; };
		_m = 2; goto P999; /* 0 */
	case 51: /* STATE 131 - line 76 "pan_in" - [(1)] (135:0:1 - 1) */
		IfNotBlocked
		reached[3][131] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(135, 133, 135) */
		reached[3][133] = 1;
		;
		/* merge: i = (i+1)(135, 134, 135) */
		reached[3][134] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->i);
		((P3 *)this)->i = (((int)((P3 *)this)->i)+1);
#ifdef VAR_RANGES
		logval("procI:i", ((int)((P3 *)this)->i));
#endif
		;
		/* merge: .(goto)(0, 136, 135) */
		reached[3][136] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 52: /* STATE 134 - line 78 "pan_in" - [i = (i+1)] (0:135:1 - 2) */
		IfNotBlocked
		reached[3][134] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->i);
		((P3 *)this)->i = (((int)((P3 *)this)->i)+1);
#ifdef VAR_RANGES
		logval("procI:i", ((int)((P3 *)this)->i));
#endif
		;
		/* merge: .(goto)(0, 136, 135) */
		reached[3][136] = 1;
		;
		_m = 3; goto P999; /* 1 */
/* STATE 140 - line 43 "pan_in" - [i = 1] (0:0 - 1) same as 47 (0:0 - 1) */
	case 53: /* STATE 141 - line 45 "pan_in" - [goto :b8] (0:236:2 - 1) */
		IfNotBlocked
		reached[3][141] = 1;
		;
		/* merge: temp_chan = proc_chan[i].C(236, 153, 236) */
		reached[3][153] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->temp_chan;
		((P3 *)this)->temp_chan = now.proc_chan[ Index(((int)((P3 *)this)->i), 8) ].C;
		/* merge: data.key = i(236, 154, 236) */
		reached[3][154] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		((P3 *)this)->data.key = ((int)((P3 *)this)->i);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		_m = 3; goto P999; /* 2 */
/* STATE 142 - line 46 "pan_in" - [i = (i+1)] (0:0 - 1) same as 48 (0:0 - 1) */
	case 54: /* STATE 143 - line 48 "pan_in" - [((i==(8-1)))] (236:0:2 - 1) */
		IfNotBlocked
		reached[3][143] = 1;
		if (!((((int)((P3 *)this)->i)==(8-1))))
			continue;
		/* merge: goto :b8(236, 144, 236) */
		reached[3][144] = 1;
		;
		/* merge: temp_chan = proc_chan[i].C(236, 153, 236) */
		reached[3][153] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->temp_chan;
		((P3 *)this)->temp_chan = now.proc_chan[ Index(((int)((P3 *)this)->i), 8) ].C;
		/* merge: data.key = i(236, 154, 236) */
		reached[3][154] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		((P3 *)this)->data.key = ((int)((P3 *)this)->i);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 55: /* STATE 153 - line 238 "pan_in" - [temp_chan = proc_chan[i].C] (0:236:2 - 4) */
		IfNotBlocked
		reached[3][153] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->temp_chan;
		((P3 *)this)->temp_chan = now.proc_chan[ Index(((int)((P3 *)this)->i), 8) ].C;
		/* merge: data.key = i(236, 154, 236) */
		reached[3][154] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.key);
		((P3 *)this)->data.key = ((int)((P3 *)this)->i);
#ifdef VAR_RANGES
		logval("procI:data.key", ((int)((P3 *)this)->data.key));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 56: /* STATE 155 - line 27 "pan_in" - [nonce = 1] (0:0:1 - 1) */
		IfNotBlocked
		reached[3][155] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->nonce);
		((P3 *)this)->nonce = 1;
#ifdef VAR_RANGES
		logval("procI:nonce", ((int)((P3 *)this)->nonce));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 57: /* STATE 156 - line 29 "pan_in" - [((known_nonce[nonce]==1))] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][156] = 1;
		if (!((((int)now.known_nonce[ Index(((int)((P3 *)this)->nonce), 8) ])==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 58: /* STATE 158 - line 31 "pan_in" - [nonce = (nonce+1)] (0:0:1 - 1) */
		IfNotBlocked
		reached[3][158] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->nonce);
		((P3 *)this)->nonce = (((int)((P3 *)this)->nonce)+1);
#ifdef VAR_RANGES
		logval("procI:nonce", ((int)((P3 *)this)->nonce));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 59: /* STATE 159 - line 33 "pan_in" - [((nonce>=8))] (182:0:2 - 1) */
		IfNotBlocked
		reached[3][159] = 1;
		if (!((((int)((P3 *)this)->nonce)>=8)))
			continue;
		/* dead 1: nonce */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->nonce;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)this)->nonce = 0;
		/* merge: nonce = 1(0, 160, 182) */
		reached[3][160] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->nonce);
		((P3 *)this)->nonce = 1;
#ifdef VAR_RANGES
		logval("procI:nonce", ((int)((P3 *)this)->nonce));
#endif
		;
		/* merge: goto :b9(0, 161, 182) */
		reached[3][161] = 1;
		;
		_m = 3; goto P999; /* 2 */
/* STATE 170 - line 43 "pan_in" - [i = 1] (0:0 - 1) same as 47 (0:0 - 1) */
	case 60: /* STATE 171 - line 45 "pan_in" - [goto :b10] (0:185:2 - 1) */
		IfNotBlocked
		reached[3][171] = 1;
		;
		/* merge: data.info1 = i(185, 183, 185) */
		reached[3][183] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)((P3 *)this)->i);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		/* merge: data.info2 = nonce(185, 184, 185) */
		reached[3][184] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.info2);
		((P3 *)this)->data.info2 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 2 */
/* STATE 172 - line 46 "pan_in" - [i = (i+1)] (0:0 - 1) same as 48 (0:0 - 1) */
	case 61: /* STATE 173 - line 48 "pan_in" - [((i==(8-1)))] (185:0:2 - 1) */
		IfNotBlocked
		reached[3][173] = 1;
		if (!((((int)((P3 *)this)->i)==(8-1))))
			continue;
		/* merge: goto :b10(185, 174, 185) */
		reached[3][174] = 1;
		;
		/* merge: data.info1 = i(185, 183, 185) */
		reached[3][183] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)((P3 *)this)->i);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		/* merge: data.info2 = nonce(185, 184, 185) */
		reached[3][184] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.info2);
		((P3 *)this)->data.info2 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 62: /* STATE 183 - line 244 "pan_in" - [data.info1 = i] (0:185:2 - 4) */
		IfNotBlocked
		reached[3][183] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)((P3 *)this)->i);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		/* merge: data.info2 = nonce(185, 184, 185) */
		reached[3][184] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->data.info2);
		((P3 *)this)->data.info2 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 63: /* STATE 185 - line 245 "pan_in" - [temp_chan!msg1,1,data.key,data.info1,data.info2] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][185] = 1;
		if (q_len(((P3 *)this)->temp_chan))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", ((P3 *)this)->temp_chan);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P3 *)this)->temp_chan, 0, 3, 1, ((int)((P3 *)this)->data.key), ((int)((P3 *)this)->data.info1), ((int)((P3 *)this)->data.info2));
		{ boq = ((P3 *)this)->temp_chan; };
		_m = 2; goto P999; /* 0 */
/* STATE 186 - line 27 "pan_in" - [nonce = 1] (0:0 - 1) same as 56 (0:0 - 1) */
	case 64: /* STATE 187 - line 29 "pan_in" - [((known_nonce[nonce]==1))] (216:0:1 - 1) */
		IfNotBlocked
		reached[3][187] = 1;
		if (!((((int)now.known_nonce[ Index(((int)((P3 *)this)->nonce), 8) ])==1)))
			continue;
		/* merge: goto :b11(216, 188, 216) */
		reached[3][188] = 1;
		;
		/* merge: data.info1 = nonce(216, 201, 216) */
		reached[3][201] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		_m = 3; goto P999; /* 2 */
/* STATE 189 - line 31 "pan_in" - [nonce = (nonce+1)] (0:0 - 1) same as 58 (0:0 - 1) */
	case 65: /* STATE 190 - line 33 "pan_in" - [((nonce>=8))] (216:0:3 - 1) */
		IfNotBlocked
		reached[3][190] = 1;
		if (!((((int)((P3 *)this)->nonce)>=8)))
			continue;
		/* dead 1: nonce */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->nonce;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)this)->nonce = 0;
		/* merge: nonce = 1(216, 191, 216) */
		reached[3][191] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->nonce);
		((P3 *)this)->nonce = 1;
#ifdef VAR_RANGES
		logval("procI:nonce", ((int)((P3 *)this)->nonce));
#endif
		;
		/* merge: goto :b11(216, 192, 216) */
		reached[3][192] = 1;
		;
		/* merge: data.info1 = nonce(216, 201, 216) */
		reached[3][201] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 66: /* STATE 201 - line 248 "pan_in" - [data.info1 = nonce] (0:216:1 - 5) */
		IfNotBlocked
		reached[3][201] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		_m = 3; goto P999; /* 0 */
/* STATE 202 - line 27 "pan_in" - [nonce = 1] (0:0 - 1) same as 56 (0:0 - 1) */
	case 67: /* STATE 203 - line 29 "pan_in" - [((known_nonce[nonce]==1))] (218:0:1 - 1) */
		IfNotBlocked
		reached[3][203] = 1;
		if (!((((int)now.known_nonce[ Index(((int)((P3 *)this)->nonce), 8) ])==1)))
			continue;
		/* merge: goto :b12(218, 204, 218) */
		reached[3][204] = 1;
		;
		/* merge: data.info2 = nonce(218, 217, 218) */
		reached[3][217] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->data.info2);
		((P3 *)this)->data.info2 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 2 */
/* STATE 205 - line 31 "pan_in" - [nonce = (nonce+1)] (0:0 - 1) same as 58 (0:0 - 1) */
	case 68: /* STATE 206 - line 33 "pan_in" - [((nonce>=8))] (218:0:3 - 1) */
		IfNotBlocked
		reached[3][206] = 1;
		if (!((((int)((P3 *)this)->nonce)>=8)))
			continue;
		/* dead 1: nonce */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->nonce;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)this)->nonce = 0;
		/* merge: nonce = 1(218, 207, 218) */
		reached[3][207] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->nonce);
		((P3 *)this)->nonce = 1;
#ifdef VAR_RANGES
		logval("procI:nonce", ((int)((P3 *)this)->nonce));
#endif
		;
		/* merge: goto :b12(218, 208, 218) */
		reached[3][208] = 1;
		;
		/* merge: data.info2 = nonce(218, 217, 218) */
		reached[3][217] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info2);
		((P3 *)this)->data.info2 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 69: /* STATE 217 - line 250 "pan_in" - [data.info2 = nonce] (0:218:1 - 5) */
		IfNotBlocked
		reached[3][217] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->data.info2);
		((P3 *)this)->data.info2 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info2", ((int)((P3 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 70: /* STATE 218 - line 251 "pan_in" - [temp_chan!msg2,1,data.key,data.info1,data.info2] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][218] = 1;
		if (q_len(((P3 *)this)->temp_chan))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", ((P3 *)this)->temp_chan);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P3 *)this)->temp_chan, 0, 2, 1, ((int)((P3 *)this)->data.key), ((int)((P3 *)this)->data.info1), ((int)((P3 *)this)->data.info2));
		{ boq = ((P3 *)this)->temp_chan; };
		_m = 2; goto P999; /* 0 */
/* STATE 219 - line 27 "pan_in" - [nonce = 1] (0:0 - 1) same as 56 (0:0 - 1) */
	case 71: /* STATE 220 - line 29 "pan_in" - [((known_nonce[nonce]==1))] (235:0:1 - 1) */
		IfNotBlocked
		reached[3][220] = 1;
		if (!((((int)now.known_nonce[ Index(((int)((P3 *)this)->nonce), 8) ])==1)))
			continue;
		/* merge: goto :b13(235, 221, 235) */
		reached[3][221] = 1;
		;
		/* merge: data.info1 = nonce(235, 234, 235) */
		reached[3][234] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		_m = 3; goto P999; /* 2 */
/* STATE 222 - line 31 "pan_in" - [nonce = (nonce+1)] (0:0 - 1) same as 58 (0:0 - 1) */
	case 72: /* STATE 223 - line 33 "pan_in" - [((nonce>=8))] (235:0:3 - 1) */
		IfNotBlocked
		reached[3][223] = 1;
		if (!((((int)((P3 *)this)->nonce)>=8)))
			continue;
		/* dead 1: nonce */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P3 *)this)->nonce;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)this)->nonce = 0;
		/* merge: nonce = 1(235, 224, 235) */
		reached[3][224] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)this)->nonce);
		((P3 *)this)->nonce = 1;
#ifdef VAR_RANGES
		logval("procI:nonce", ((int)((P3 *)this)->nonce));
#endif
		;
		/* merge: goto :b13(235, 225, 235) */
		reached[3][225] = 1;
		;
		/* merge: data.info1 = nonce(235, 234, 235) */
		reached[3][234] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 73: /* STATE 234 - line 254 "pan_in" - [data.info1 = nonce] (0:235:1 - 5) */
		IfNotBlocked
		reached[3][234] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)this)->data.info1);
		((P3 *)this)->data.info1 = ((int)((P3 *)this)->nonce);
#ifdef VAR_RANGES
		logval("procI:data.info1", ((int)((P3 *)this)->data.info1));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 74: /* STATE 235 - line 255 "pan_in" - [temp_chan!msg3,1,data.key,data.info1,data.info2] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][235] = 1;
		if (q_len(((P3 *)this)->temp_chan))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", ((P3 *)this)->temp_chan);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P3 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P3 *)this)->temp_chan, 0, 1, 1, ((int)((P3 *)this)->data.key), ((int)((P3 *)this)->data.info1), ((int)((P3 *)this)->data.info2));
		{ boq = ((P3 *)this)->temp_chan; };
		_m = 2; goto P999; /* 0 */
	case 75: /* STATE 242 - line 259 "pan_in" - [-end-] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][242] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC procB */
	case 76: /* STATE 1 - line 133 "pan_in" - [my_chan?msg1,_,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[2][1] = 1;
		if (boq != ((P2 *)this)->my_chan) continue;
		if (q_len(((P2 *)this)->my_chan) == 0) continue;

		XX=1;
		if (3 != qrecv(((P2 *)this)->my_chan, 0, 0, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = qrecv(((P2 *)this)->my_chan, XX-1, 1, 0);
		(trpt+1)->bup.ovals[1] = ((int)((P2 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P2 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P2 *)this)->data.info2);
		;
		qrecv(((P2 *)this)->my_chan, XX-1, 1, 0);
		((P2 *)this)->data.key = qrecv(((P2 *)this)->my_chan, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procB:data.key", ((int)((P2 *)this)->data.key));
#endif
		;
		((P2 *)this)->data.info1 = qrecv(((P2 *)this)->my_chan, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procB:data.info1", ((int)((P2 *)this)->data.info1));
#endif
		;
		((P2 *)this)->data.info2 = qrecv(((P2 *)this)->my_chan, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procB:data.info2", ((int)((P2 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P2 *)this)->my_chan);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)_)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(((P2 *)this)->my_chan))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 77: /* STATE 2 - line 135 "pan_in" - [((data.key==_pid))] (0:0:0 - 1) */
		IfNotBlocked
		reached[2][2] = 1;
		if (!((((int)((P2 *)this)->data.key)==((int)((P2 *)this)->_pid))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 78: /* STATE 7 - line 138 "pan_in" - [partner = data.info1] (0:16:9 - 1) */
		IfNotBlocked
		reached[2][7] = 1;
		(trpt+1)->bup.ovals = grab_ints(9);
		(trpt+1)->bup.ovals[0] = ((int)((P2 *)this)->partner);
		((P2 *)this)->partner = ((int)((P2 *)this)->data.info1);
#ifdef VAR_RANGES
		logval("procB:partner", ((int)((P2 *)this)->partner));
#endif
		;
		/* merge: p_nonce = data.info2(16, 8, 16) */
		reached[2][8] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P2 *)this)->p_nonce);
		((P2 *)this)->p_nonce = ((int)((P2 *)this)->data.info2);
#ifdef VAR_RANGES
		logval("procB:p_nonce", ((int)((P2 *)this)->p_nonce));
#endif
		;
		/* merge: nonce_introduced[p_nonce] = 1(16, 9, 16) */
		reached[2][9] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.nonce_introduced[ Index(((int)((P2 *)this)->p_nonce), 8) ]);
		now.nonce_introduced[ Index(((P2 *)this)->p_nonce, 8) ] = 1;
#ifdef VAR_RANGES
		logval("nonce_introduced[procB:p_nonce]", ((int)now.nonce_introduced[ Index(((int)((P2 *)this)->p_nonce), 8) ]));
#endif
		;
		/* merge: p_chan = proc_chan[partner].C(16, 10, 16) */
		reached[2][10] = 1;
		(trpt+1)->bup.ovals[3] = ((P2 *)this)->p_chan;
		((P2 *)this)->p_chan = now.proc_chan[ Index(((int)((P2 *)this)->partner), 8) ].C;
		/* merge: used_nonce = (used_nonce+1)(16, 11, 16) */
		reached[2][11] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.used_nonce);
		now.used_nonce = (((int)now.used_nonce)+1);
#ifdef VAR_RANGES
		logval("used_nonce", ((int)now.used_nonce));
#endif
		;
		/* merge: my_nonce = used_nonce(16, 12, 16) */
		reached[2][12] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P2 *)this)->my_nonce);
		((P2 *)this)->my_nonce = ((int)now.used_nonce);
#ifdef VAR_RANGES
		logval("procB:my_nonce", ((int)((P2 *)this)->my_nonce));
#endif
		;
		/* merge: data.key = partner(16, 13, 16) */
		reached[2][13] = 1;
		(trpt+1)->bup.ovals[6] = ((int)((P2 *)this)->data.key);
		((P2 *)this)->data.key = ((int)((P2 *)this)->partner);
#ifdef VAR_RANGES
		logval("procB:data.key", ((int)((P2 *)this)->data.key));
#endif
		;
		/* merge: data.info1 = p_nonce(16, 14, 16) */
		reached[2][14] = 1;
		(trpt+1)->bup.ovals[7] = ((int)((P2 *)this)->data.info1);
		((P2 *)this)->data.info1 = ((int)((P2 *)this)->p_nonce);
#ifdef VAR_RANGES
		logval("procB:data.info1", ((int)((P2 *)this)->data.info1));
#endif
		;
		/* merge: data.info2 = my_nonce(16, 15, 16) */
		reached[2][15] = 1;
		(trpt+1)->bup.ovals[8] = ((int)((P2 *)this)->data.info2);
		((P2 *)this)->data.info2 = ((int)((P2 *)this)->my_nonce);
#ifdef VAR_RANGES
		logval("procB:data.info2", ((int)((P2 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 8 */
	case 79: /* STATE 16 - line 145 "pan_in" - [p_chan!msg2,0,data.key,data.info1,data.info2] (0:0:0 - 1) */
		IfNotBlocked
		reached[2][16] = 1;
		if (q_len(((P2 *)this)->p_chan))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", ((P2 *)this)->p_chan);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P2 *)this)->p_chan, 0, 2, 0, ((int)((P2 *)this)->data.key), ((int)((P2 *)this)->data.info1), ((int)((P2 *)this)->data.info2));
		{ boq = ((P2 *)this)->p_chan; };
		_m = 2; goto P999; /* 0 */
	case 80: /* STATE 18 - line 147 "pan_in" - [my_chan?msg3,_,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[2][18] = 1;
		if (boq != ((P2 *)this)->my_chan) continue;
		if (q_len(((P2 *)this)->my_chan) == 0) continue;

		XX=1;
		if (1 != qrecv(((P2 *)this)->my_chan, 0, 0, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = qrecv(((P2 *)this)->my_chan, XX-1, 1, 0);
		(trpt+1)->bup.ovals[1] = ((int)((P2 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P2 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P2 *)this)->data.info2);
		;
		qrecv(((P2 *)this)->my_chan, XX-1, 1, 0);
		((P2 *)this)->data.key = qrecv(((P2 *)this)->my_chan, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procB:data.key", ((int)((P2 *)this)->data.key));
#endif
		;
		((P2 *)this)->data.info1 = qrecv(((P2 *)this)->my_chan, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procB:data.info1", ((int)((P2 *)this)->data.info1));
#endif
		;
		((P2 *)this)->data.info2 = qrecv(((P2 *)this)->my_chan, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procB:data.info2", ((int)((P2 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P2 *)this)->my_chan);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)_)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P2 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(((P2 *)this)->my_chan))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 81: /* STATE 19 - line 149 "pan_in" - [(((data.key==_pid)&&(data.info1==my_nonce)))] (0:0:1 - 1) */
		IfNotBlocked
		reached[2][19] = 1;
		if (!(((((int)((P2 *)this)->data.key)==((int)((P2 *)this)->_pid))&&(((int)((P2 *)this)->data.info1)==((int)((P2 *)this)->my_nonce)))))
			continue;
		/* dead 1: my_nonce */  (trpt+1)->bup.oval = ((P2 *)this)->my_nonce;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)this)->my_nonce = 0;
		_m = 3; goto P999; /* 0 */
	case 82: /* STATE 24 - line 151 "pan_in" - [-end-] (0:0:0 - 3) */
		IfNotBlocked
		reached[2][24] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC procA */
	case 83: /* STATE 1 - line 43 "pan_in" - [i = 1] (0:0:1 - 1) */
		IfNotBlocked
		reached[1][1] = 1;
		(trpt+1)->bup.oval = ((int)((P1 *)this)->i);
		((P1 *)this)->i = 1;
#ifdef VAR_RANGES
		logval("procA:i", ((int)((P1 *)this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 84: /* STATE 2 - line 45 "pan_in" - [goto :b1] (0:20:6 - 1) */
		IfNotBlocked
		reached[1][2] = 1;
		;
		/* merge: p_chan = proc_chan[i].C(20, 14, 20) */
		reached[1][14] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P1 *)this)->p_chan;
		((P1 *)this)->p_chan = now.proc_chan[ Index(((int)((P1 *)this)->i), 8) ].C;
		/* merge: used_nonce = (used_nonce+1)(20, 15, 20) */
		reached[1][15] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.used_nonce);
		now.used_nonce = (((int)now.used_nonce)+1);
#ifdef VAR_RANGES
		logval("used_nonce", ((int)now.used_nonce));
#endif
		;
		/* merge: my_nonce = used_nonce(20, 16, 20) */
		reached[1][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)this)->my_nonce);
		((P1 *)this)->my_nonce = ((int)now.used_nonce);
#ifdef VAR_RANGES
		logval("procA:my_nonce", ((int)((P1 *)this)->my_nonce));
#endif
		;
		/* merge: data.key = i(20, 17, 20) */
		reached[1][17] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)this)->data.key);
		((P1 *)this)->data.key = ((int)((P1 *)this)->i);
#ifdef VAR_RANGES
		logval("procA:data.key", ((int)((P1 *)this)->data.key));
#endif
		;
		/* merge: data.info1 = _pid(20, 18, 20) */
		reached[1][18] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)this)->data.info1);
		((P1 *)this)->data.info1 = ((int)((P1 *)this)->_pid);
#ifdef VAR_RANGES
		logval("procA:data.info1", ((int)((P1 *)this)->data.info1));
#endif
		;
		/* merge: data.info2 = my_nonce(20, 19, 20) */
		reached[1][19] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P1 *)this)->data.info2);
		((P1 *)this)->data.info2 = ((int)((P1 *)this)->my_nonce);
#ifdef VAR_RANGES
		logval("procA:data.info2", ((int)((P1 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 6 */
	case 85: /* STATE 3 - line 46 "pan_in" - [i = (i+1)] (0:0:1 - 1) */
		IfNotBlocked
		reached[1][3] = 1;
		(trpt+1)->bup.oval = ((int)((P1 *)this)->i);
		((P1 *)this)->i = (((int)((P1 *)this)->i)+1);
#ifdef VAR_RANGES
		logval("procA:i", ((int)((P1 *)this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 86: /* STATE 4 - line 48 "pan_in" - [((i==(8-1)))] (20:0:6 - 1) */
		IfNotBlocked
		reached[1][4] = 1;
		if (!((((int)((P1 *)this)->i)==(8-1))))
			continue;
		/* merge: goto :b1(20, 5, 20) */
		reached[1][5] = 1;
		;
		/* merge: p_chan = proc_chan[i].C(20, 14, 20) */
		reached[1][14] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P1 *)this)->p_chan;
		((P1 *)this)->p_chan = now.proc_chan[ Index(((int)((P1 *)this)->i), 8) ].C;
		/* merge: used_nonce = (used_nonce+1)(20, 15, 20) */
		reached[1][15] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.used_nonce);
		now.used_nonce = (((int)now.used_nonce)+1);
#ifdef VAR_RANGES
		logval("used_nonce", ((int)now.used_nonce));
#endif
		;
		/* merge: my_nonce = used_nonce(20, 16, 20) */
		reached[1][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)this)->my_nonce);
		((P1 *)this)->my_nonce = ((int)now.used_nonce);
#ifdef VAR_RANGES
		logval("procA:my_nonce", ((int)((P1 *)this)->my_nonce));
#endif
		;
		/* merge: data.key = i(20, 17, 20) */
		reached[1][17] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)this)->data.key);
		((P1 *)this)->data.key = ((int)((P1 *)this)->i);
#ifdef VAR_RANGES
		logval("procA:data.key", ((int)((P1 *)this)->data.key));
#endif
		;
		/* merge: data.info1 = _pid(20, 18, 20) */
		reached[1][18] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)this)->data.info1);
		((P1 *)this)->data.info1 = ((int)((P1 *)this)->_pid);
#ifdef VAR_RANGES
		logval("procA:data.info1", ((int)((P1 *)this)->data.info1));
#endif
		;
		/* merge: data.info2 = my_nonce(20, 19, 20) */
		reached[1][19] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P1 *)this)->data.info2);
		((P1 *)this)->data.info2 = ((int)((P1 *)this)->my_nonce);
#ifdef VAR_RANGES
		logval("procA:data.info2", ((int)((P1 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 7 */
	case 87: /* STATE 14 - line 110 "pan_in" - [p_chan = proc_chan[i].C] (0:20:6 - 4) */
		IfNotBlocked
		reached[1][14] = 1;
		(trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P1 *)this)->p_chan;
		((P1 *)this)->p_chan = now.proc_chan[ Index(((int)((P1 *)this)->i), 8) ].C;
		/* merge: used_nonce = (used_nonce+1)(20, 15, 20) */
		reached[1][15] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.used_nonce);
		now.used_nonce = (((int)now.used_nonce)+1);
#ifdef VAR_RANGES
		logval("used_nonce", ((int)now.used_nonce));
#endif
		;
		/* merge: my_nonce = used_nonce(20, 16, 20) */
		reached[1][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)this)->my_nonce);
		((P1 *)this)->my_nonce = ((int)now.used_nonce);
#ifdef VAR_RANGES
		logval("procA:my_nonce", ((int)((P1 *)this)->my_nonce));
#endif
		;
		/* merge: data.key = i(20, 17, 20) */
		reached[1][17] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)this)->data.key);
		((P1 *)this)->data.key = ((int)((P1 *)this)->i);
#ifdef VAR_RANGES
		logval("procA:data.key", ((int)((P1 *)this)->data.key));
#endif
		;
		/* merge: data.info1 = _pid(20, 18, 20) */
		reached[1][18] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)this)->data.info1);
		((P1 *)this)->data.info1 = ((int)((P1 *)this)->_pid);
#ifdef VAR_RANGES
		logval("procA:data.info1", ((int)((P1 *)this)->data.info1));
#endif
		;
		/* merge: data.info2 = my_nonce(20, 19, 20) */
		reached[1][19] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P1 *)this)->data.info2);
		((P1 *)this)->data.info2 = ((int)((P1 *)this)->my_nonce);
#ifdef VAR_RANGES
		logval("procA:data.info2", ((int)((P1 *)this)->data.info2));
#endif
		;
		_m = 3; goto P999; /* 5 */
	case 88: /* STATE 20 - line 114 "pan_in" - [p_chan!msg1,0,data.key,data.info1,data.info2] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][20] = 1;
		if (q_len(((P1 *)this)->p_chan))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", ((P1 *)this)->p_chan);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P1 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P1 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P1 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)this)->p_chan, 0, 3, 0, ((int)((P1 *)this)->data.key), ((int)((P1 *)this)->data.info1), ((int)((P1 *)this)->data.info2));
		{ boq = ((P1 *)this)->p_chan; };
		_m = 2; goto P999; /* 0 */
	case 89: /* STATE 22 - line 116 "pan_in" - [my_chan?msg2,_,data.key,data.info1,data.info2] (0:0:4 - 1) */
		reached[1][22] = 1;
		if (boq != ((P1 *)this)->my_chan) continue;
		if (q_len(((P1 *)this)->my_chan) == 0) continue;

		XX=1;
		if (2 != qrecv(((P1 *)this)->my_chan, 0, 0, 0)) continue;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = qrecv(((P1 *)this)->my_chan, XX-1, 1, 0);
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)this)->data.key);
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)this)->data.info1);
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)this)->data.info2);
		;
		qrecv(((P1 *)this)->my_chan, XX-1, 1, 0);
		((P1 *)this)->data.key = qrecv(((P1 *)this)->my_chan, XX-1, 2, 0);
#ifdef VAR_RANGES
		logval("procA:data.key", ((int)((P1 *)this)->data.key));
#endif
		;
		((P1 *)this)->data.info1 = qrecv(((P1 *)this)->my_chan, XX-1, 3, 0);
#ifdef VAR_RANGES
		logval("procA:data.info1", ((int)((P1 *)this)->data.info1));
#endif
		;
		((P1 *)this)->data.info2 = qrecv(((P1 *)this)->my_chan, XX-1, 4, 1);
#ifdef VAR_RANGES
		logval("procA:data.info2", ((int)((P1 *)this)->data.info2));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P1 *)this)->my_chan);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)_)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P1 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P1 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P1 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		if (q_zero(((P1 *)this)->my_chan))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3d: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 90: /* STATE 23 - line 118 "pan_in" - [(((data.key==_pid)&&(data.info1==my_nonce)))] (0:0:1 - 1) */
		IfNotBlocked
		reached[1][23] = 1;
		if (!(((((int)((P1 *)this)->data.key)==((int)((P1 *)this)->_pid))&&(((int)((P1 *)this)->data.info1)==((int)((P1 *)this)->my_nonce)))))
			continue;
		/* dead 1: my_nonce */  (trpt+1)->bup.oval = ((P1 *)this)->my_nonce;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)this)->my_nonce = 0;
		_m = 3; goto P999; /* 0 */
	case 91: /* STATE 28 - line 121 "pan_in" - [recvd_nonce = data.info2] (0:32:4 - 1) */
		IfNotBlocked
		reached[1][28] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)this)->recvd_nonce);
		((P1 *)this)->recvd_nonce = ((int)((P1 *)this)->data.info2);
#ifdef VAR_RANGES
		logval("procA:recvd_nonce", ((int)((P1 *)this)->recvd_nonce));
#endif
		;
		/* merge: nonce_introduced[recvd_nonce] = 1(32, 29, 32) */
		reached[1][29] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.nonce_introduced[ Index(((int)((P1 *)this)->recvd_nonce), 8) ]);
		now.nonce_introduced[ Index(((P1 *)this)->recvd_nonce, 8) ] = 1;
#ifdef VAR_RANGES
		logval("nonce_introduced[procA:recvd_nonce]", ((int)now.nonce_introduced[ Index(((int)((P1 *)this)->recvd_nonce), 8) ]));
#endif
		;
		/* merge: data.key = i(32, 30, 32) */
		reached[1][30] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)this)->data.key);
		((P1 *)this)->data.key = ((int)((P1 *)this)->i);
#ifdef VAR_RANGES
		logval("procA:data.key", ((int)((P1 *)this)->data.key));
#endif
		;
		/* merge: data.info1 = recvd_nonce(32, 31, 32) */
		reached[1][31] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)this)->data.info1);
		((P1 *)this)->data.info1 = ((int)((P1 *)this)->recvd_nonce);
#ifdef VAR_RANGES
		logval("procA:data.info1", ((int)((P1 *)this)->data.info1));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 92: /* STATE 32 - line 124 "pan_in" - [p_chan!msg3,0,data.key,data.info1,data.info2] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][32] = 1;
		if (q_len(((P1 *)this)->p_chan))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d!", ((P1 *)this)->p_chan);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", 0); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P1 *)this)->data.key)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P1 *)this)->data.info1)); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((int)((P1 *)this)->data.info2)); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)this)->p_chan, 0, 1, 0, ((int)((P1 *)this)->data.key), ((int)((P1 *)this)->data.info1), ((int)((P1 *)this)->data.info2));
		{ boq = ((P1 *)this)->p_chan; };
		_m = 2; goto P999; /* 0 */
	case 93: /* STATE 34 - line 126 "pan_in" - [-end-] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][34] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 94: /* STATE 1 - line 83 "pan_in" - [(run procI(1))] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][1] = 1;
		if (!(addproc(3, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 95: /* STATE 2 - line 84 "pan_in" - [(run procA(2))] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][2] = 1;
		if (!(addproc(1, 2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 96: /* STATE 3 - line 85 "pan_in" - [(run procB(3))] (16:0:1 - 1) */
		IfNotBlocked
		reached[0][3] = 1;
		if (!(addproc(2, 3)))
			continue;
		/* merge: j = 3(0, 4, 16) */
		reached[0][4] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)this)->j);
		((P0 *)this)->j = 3;
#ifdef VAR_RANGES
		logval(":init::j", ((int)((P0 *)this)->j));
#endif
		;
		/* merge: .(goto)(0, 17, 16) */
		reached[0][17] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 97: /* STATE 6 - line 89 "pan_in" - [j = (j+1)] (0:0:1 - 1) */
		IfNotBlocked
		reached[0][6] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)this)->j);
		((P0 *)this)->j = (((int)((P0 *)this)->j)+1);
#ifdef VAR_RANGES
		logval(":init::j", ((int)((P0 *)this)->j));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 98: /* STATE 7 - line 91 "pan_in" - [((j>=8))] (0:0:1 - 1) */
		IfNotBlocked
		reached[0][7] = 1;
		if (!((((int)((P0 *)this)->j)>=8)))
			continue;
		/* dead 1: j */  (trpt+1)->bup.oval = ((P0 *)this)->j;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)this)->j = 0;
		_m = 3; goto P999; /* 0 */
	case 99: /* STATE 10 - line 95 "pan_in" - [(run procA(j))] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][10] = 1;
		if (!(addproc(1, ((int)((P0 *)this)->j))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 100: /* STATE 11 - line 96 "pan_in" - [(run procB(j))] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][11] = 1;
		if (!(addproc(2, ((int)((P0 *)this)->j))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 101: /* STATE 19 - line 100 "pan_in" - [-end-] (0:0:0 - 4) */
		IfNotBlocked
		reached[0][19] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

